
let items = document.querySelectorAll('.slider .item');
let next = document.getElementById('next');
let prev = document.getElementById('prev');
let thumbnails = document.querySelectorAll('.thumbnail .item');
let countItem = items.length;
let itemActive = 0;

// Next button click
next.onclick = function () {
    itemActive = (itemActive + 1) % countItem;
    showSlider();
};

// Previous button click
prev.onclick = function () {
    itemActive = (itemActive - 1 + countItem) % countItem;
    showSlider();
};

// Auto-slide interval
let refreshInterval = setInterval(() => {
    next.click();
}, 3000);

// Show the active slider and thumbnail
function showSlider() {
    let itemActiveOld = document.querySelector('.slider .list .item.active');
    let thumbnailActiveOld = document.querySelector('.thumbnail .item.active');

    // Remove 'active' class from the current active slider and thumbnail
    if (itemActiveOld) itemActiveOld.classList.remove('active');
    if (thumbnailActiveOld) thumbnailActiveOld.classList.remove('active');

    // Add 'active' class to the new active slider and thumbnail
    items[itemActive].classList.add('active');
    thumbnails[itemActive].classList.add('active');

    // Reset the auto-slide interval
    clearInterval(refreshInterval);
    refreshInterval = setInterval(() => {
        next.click();
    }, 3000);
}

// Thumbnail click to navigate
thumbnails.forEach((thumbnail, index) => {
    thumbnail.addEventListener('click', () => {
        itemActive = index;
        showSlider();
    });
});
