<?php  
require_once('connection.php');  

if (isset($_GET['action']) && isset($_GET['email'])) {  
    $email = $_GET['email'];  
    $action = $_GET['action'];  

    // Fetch the name associated with the email  
    $query = "SELECT name FROM applying WHERE email = ?";  
    $stmt = $con->prepare($query);  
    $stmt->bind_param("s", $email);  
    $stmt->execute();  
    $result = $stmt->get_result();  
    
    if ($result->num_rows > 0) {  
        $row = $result->fetch_assoc();  
        $name = $row['name'];  
        
        // Prepare insert query  
        $status = ($action == 'accept') ? 'accepted' : 'rejected';  
        $insertQuery = "INSERT INTO rejoracc (name, status) VALUES (?, ?)";  
        $insertStmt = $con->prepare($insertQuery);  
        $insertStmt->bind_param("ss", $name, $status);  
        $insertStmt->execute();  
    }  

    // Redirect to the page with a success message  
    header("Location: admin_table.php?status=" . ($status == 'accepted' ? 'accepted' : 'rejected'));  
    exit();  
}  
?>