<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Dashboard</title>
    <style>
      body{
        background-image: url('graduation-white.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        width: auto;
        text-align: center;
        font-family: Helvetica;
      }
      header{
        text-align: center;
        color: darkcyan;
        font-size: xx-large;
      }
      .faded{
        height: 250px;
        width: auto;
        margin: 0 100px;
        padding: 120px;
      }
      .boxes{
        width: 250px;
        color: white;
        background-color: darkcyan;
        display: inline-block;
        margin-left: 15px
      }
      .clickhere{
        color: white;
        padding: 8px;
        border: 1px white solid;
        border-radius: 20px;
        text-decoration: none;
      }
      .clickhere:hover{
        color: darkcyan;
        background-color: white;
        border: 1px black solid;
      }
      .clickhere:active{
        color: white;
        border: 1px white solid;
        background-color: darkcyan;
      }

      .footer {  
            background-color:none; 
            color: rgb(0, 0, 0);  
            text-align: center;  
            padding: 20px 0;  
        }  
    </style>
  </head>
  <body>
    <header>
      <h1>
        Career Guidance
      </h1>
    </header>
    <div class="faded">
      <div class="boxes" >
        <h2 style="height: 45px;">
          Faculties
        </h2>
        <p style="height: 70px;">

        </p>
        <div  style="height: 45px;">
          <a  class="clickhere"  href="institutetable.php">Click Here &#8594;</a>
        </div>
      </div>

      <div class="boxes" >
        <h2 style="height: 45px;">
          Profile
        </h2>

        <p style="height: 70px;">
        </p>

        <div style="height: 45px;">
          <a  class="clickhere" href="profile2.html">Click Here &#8594;</a>
        </div>
      </div>

      <div class="boxes" >
        <h2 style="height: 45px;">
          Admissions
        </h2>

        <p style="height: 70px;">
        </p>

        <div style="height: 45px;">
          <a  class="clickhere" href="applying.php">Click Here &#8594;</a>
        </div>

      </div>

      
    </div>

    <footer class="footer">  
      <p>Terms and Conditions | Privacy Policy | Cookie Policy</p>  
      <h6 id="footerYear">&copy; <script>document.write(new Date().getFullYear());</script> Career Guidance || Contact Details:59999999</h6>  
      <div class="fafa">  
          <a href="#"><i class="fa fa-facebook"></i></a>  
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-instagram"></i></a>  
          <a href="#"><i class="fa fa-whatsapp"></i></a>  
          <a href="#"><i class="fa fa-google"></i></a>  
      </div>  
  </footer>  

  </body>
</html>