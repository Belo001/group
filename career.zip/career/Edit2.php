<?php
// Connect to the database
$con = mysqli_connect("localhost", "root", "", "career");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check 'id' 
if (isset($_GET['id'])) {
    // Use the id to fetch the record
    $id = mysqli_real_escape_string($con, $_GET['id']);
    
    // Fetch record with the specified id
    $query = "SELECT * FROM faculty WHERE id = '$id'";
    $result = mysqli_query($con, $query);
    
    // Check if a record was found
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>

    <style>
        
        form h3 {
        margin-bottom: 20px;
        font-size: 24px;
        color: #333;
    }
    
    form label {
        display: block;
        margin-top: 10px;
        font-weight: bold;
    }
    
    form input {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    
    form button {
        width: 100%;
        padding: 10px;
        margin-top: 20px;
        background-color: #f4511e;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }
    
    form button:hover {
        background-color: #e0401a;
    }
        </style>
</head>
<body>
    <h2>Edit Record</h2>
    <form action="update2.php" method="POST">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
        Faculty Name: <input type="text" name="faculty_name" value="<?php echo htmlspecialchars($row['faculty_name']); ?>"><br>
        Program Name: <input type="text" name="program_name" value="<?php echo htmlspecialchars($row['program_name']); ?>"><br>
        Entry Requirements: <input type="text" name="entry_requirements" value="<?php echo htmlspecialchars($row['entry_requirements']); ?>"><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>

<?php
    } else {
        echo "No record found.";
    }
} else {
    echo "ID not provided in URL.";
}

// Close connection
mysqli_close($con);
?>