<?php  
session_start();   
include('connection.php'); // database connection  

if (isset($_POST['submit'])) {  
  
    $names = $_POST['names'];  
    $dob = $_POST['dob'];  
    $phone_number = $_POST['phone_number'];  
    $email = $_POST['email'];  
    $username = $_POST['username'];  
    $password = $_POST['password'];  

    // Check or create email unique
    $verify_query = mysqli_query($con, "SELECT Email FROM studentreg WHERE Email='$email'");  

    if (mysqli_num_rows($verify_query) != 0) {  
        echo "<div class='message'>  
        <p>This email is already used, please try another one!</p>  
        </div><br>";  
        echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button></a>";  
    } else {  
        // Hash password for security  
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);  
        
        // Insert user data into the database  
        $insert_query = mysqli_query($con, "INSERT INTO studentreg (Names, DOB, Phone_Number, Email, Username, Password) VALUES ('$names', '$dob', '$phone_number', '$email', '$username', '$hashed_password')");  

        if ($insert_query) {  
            // Log in the user  
            $_SESSION['valid'] = $email;  
            $_SESSION['username'] = $username;  
            $_SESSION['phone'] = $phone_number;  
            
            
            header("Location: StudentLogin.php");  
            exit;  
        } else {  
            echo "<p>Error occurred during registration: " . mysqli_error($con) . "</p>";  
        }  
    }  
} else {  
?>  

<!DOCTYPE html>  
<html>  
<head>  
    <title>Student Register</title>  

    
<style>  

body{
    font-family: Helvetica;
}
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin-top: 30px;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}


* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-color: #f4f4f4;
}

.header {
    position: fixed;
    top: 0;
    width: 100%;
    padding: 20px;
    background-color: #333;
    color: #fff;
    text-align: center;
}

.header nav a {
    margin: 0 10px;
    color: #fff;
    text-decoration: none;
}

.container {
    background-image: url("graduation.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    margin:auto;
}

.signup-form h3 {
    margin-bottom: 20px;
    font-size: 50px;
    color: darkcyan;
    text-align: center;
    text-decoration: underline overline;
}

.signup-form label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
}

.signup-form input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.signup-form button {
    width: 100%;
    padding: 10px;
    margin-top: 20px;
    background-color: #f4511e;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

.signup-form button:hover {
    background-color: #e0401a;
}


        body {  
            font-family: Arial, sans-serif;  
            background-color: #f4f4f4;  
            margin: 0;  
            padding: 20px;  
        }  
        input {  
            width: 100%;  
            padding: 10px;  
            margin: 10px 0;  
            border: 1px solid #ccc;  
            border-radius: 4px;  
        }  
        button {  
            background-color: #5cb85c;  
            color: white;  
            padding: 10px;  
            border: none;  
            border-radius: 5px;  
            cursor: pointer;  
        }  
        button:hover {  
            background-color: #4cae4c;  
        }  
    </style>  

</head> 
 
<body>  

<header style="text-align: center; margin-bottom: 8px;">  
        <h1>Career Guidance</h1><br>  
        <h2>Student Register</h2><br>  
        <nav style="color: darkcyan;">  
            <a href="Dashboard.php">Home</a>  
            <a href="#" style="border-left: 1px white solid; border-right: 1px white solid;">Settings</a>  
            <a href="StudentLogin.php">Login</a>  
        </nav>  
        <nav>  
            <input type="search" class="srch" placeholder="Type to search ...">  
            <button class="btn">Search</button>  
        </nav>  
</header>  

<div class="container">  
    <form action="" method="POST" class="signup-form">  
        <h3>Sign Up</h3>  
        <label for="names">Names *</label>  
        <input type="text" id="names" name="names" placeholder="Enter your full name" required>  

        <label for="dob">D.O.B *</label>  
        <input type="date" id="dob" name="dob" required>  

        <label for="phone_number">Phone Number *</label>  
        <input type="tel" id="phone_number" name="phone_number" placeholder="Enter your phone number" required>  

        <label for="email">Email *</label>  
        <input type="email" id="email" name="email" placeholder="Enter your email address" required>  

        <label for="username">Username *</label>  
        <input type="text" id="username" name="username" placeholder="Choose a username" required>  

        <label for="password">Password *</label>  
        <input type="password" id="password" name="password" placeholder="Create a password" required>  

        <button type="submit" name="submit">Sign Up</button>  
    </form>  
</div>  

<?php  
}  
?>  
</body>  
</html>