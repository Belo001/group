<?php   
require_once('connection.php');  
$query = "SELECT * FROM adminreg";  
$result = mysqli_query($con, $query);  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta http-equiv="X-UA-Compatible" content="IE=edge">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">  
    <title>Fetch Data From Database in Php</title>   
    
    <style>  
        body {  
            background-color: #343a40;  
            color: #ffffff;  
            font-family: Arial, sans-serif;  
        }  
        .container {  
            width: 80%;  
            margin: auto;  
            text-align: center;  
        }  
        h2 {  
            margin: 20px 0;  
        }  
        table {  
            width: 100%;  
            border-collapse: collapse;  
            margin: 20px 0;  
        }  
        th, td {  
            border: 1px solid #ffffff;  
            padding: 10px;  
            text-align: left;  
        }  
        th {  
            background-color: #495057;  
        }  
        tr:nth-child(even) {  
            background-color: #6c757d;  
        }  
        tr:hover {  
            background-color: #adb5bd;  
        }  
    </style>  
</head>  
<body class="bg-dark">  
    <div class="container">  
        <div class="row mt-5">  
            <div class="col">   
                <div class="card mt-5">   
                    <div class="card-header">  
                        <h2 class="display-6 text-center">Admin Table</h2>  
                    </div>  
                    <div class="card-body">  
                        <table class="table text-center">  
                            <thead class="bg-dark text-white">  
                                <tr>  
                                    <th>Id</th> 
                                    <th>Username</th>   
                                    <th>Email</th>  
                                    <th>Phone Number</th>  
                                    <th>Password</th>  
                                    <th>Edit</th>  
                                    <th>Delete</th>  
                                </tr>  
                            </thead>  
                            <tbody>  
                                <?php  
                                // Check if there are any rows returned  
                                if (mysqli_num_rows($result) > 0) {  
                                    while ($row = mysqli_fetch_assoc($result)) {  
                                ?>  
                                    <tr>  
                                        <td><?php echo htmlspecialchars($row['Id']); ?></td>  
                                        <td><?php echo htmlspecialchars($row['Username']); ?></td>   
                                        <td><?php echo htmlspecialchars($row['Email']); ?></td>   
                                        <td><?php echo htmlspecialchars($row['Phone_Number']); ?></td>   
                                        <td><?php echo htmlspecialchars($row['Password']); ?></td>   
                                        <td><a href="Edit.php?email=<?php echo urlencode($row['Email']); ?>" class="btn btn-primary"><h2>&#128221;</h2></a></td>
                                        <td><a href="delete.php?email=<?php echo urlencode($row['Email']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this record?');"> <h1><i class="fa fa-trash"></i></h1> </a></td>  
                                    </tr>  
                                <?php  
                                    }  
                                } else {  
                                    echo "<tr><td colspan='6'>No records found</td></tr>";  
                                }  
                                ?>  
                            </tbody>  
                        </table>  
                    </div>   
                </div>   
            </div>  
        </div>  
    </div>  
</body>  
</html>