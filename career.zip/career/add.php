<?php  
require_once('connection.php');  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $username = mysqli_real_escape_string($con, $_POST['username']);  
    $email = mysqli_real_escape_string($con, $_POST['email']);  
    $phone = mysqli_real_escape_string($con, $_POST['phone']);  
    $password = mysqli_real_escape_string($con, $_POST['password']);  

    $query = "INSERT INTO adminreg (Username, Email, Phone_Number, Password) VALUES ('$username', '$email', '$phone', '$password')";  
    
    if (mysqli_query($con, $query)) {  
 
        header('Location: index.php');  
        exit;  
    } else {  
        echo "Error: " . mysqli_error($con);  
    }  
}  
?>

