document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const message = document.getElementById('message').value.trim();
  
    // Email Validation Regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
    if (!username || !email || !phone || !message) {
      alert('Please fill in all fields.');
      return;
    }
  
    if (!emailRegex.test(email)) {
      alert('Please enter a valid email address.');
      return;
    }
  
    // Animation feedback
    const button = document.querySelector('button');
    button.textContent = 'Sending...';
    button.disabled = true;
  
    setTimeout(() => {
      alert(`Thank you for reaching out, ${username}!`` We will get back to you soon.`);
      document.getElementById('contact-form').reset();
      button.textContent = 'Send';
      button.disabled = false;
    }, 2000);
  });