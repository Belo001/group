<?php  
$con = mysqli_connect("localhost", "root", "", "career");  

if (!$con) {  
    die("Connection failed: " . mysqli_connect_error());  
}  

$message = ""; // modal message  

if (isset($_GET['id'])) {  
    $id = mysqli_real_escape_string($con, $_GET['id']); // Use 'id'  

    // DELETE statement  
    $query = "DELETE FROM faculty WHERE id = ?";  
    $stmt = mysqli_prepare($con, $query);  

    if ($stmt) {  
        mysqli_stmt_bind_param($stmt, "i", $id); 
        mysqli_stmt_execute($stmt);  

        if (mysqli_stmt_affected_rows($stmt) > 0) {  
            $message = "Record deleted successfully.";  
        } else {  
            $message = "No record found with that ID or record not deleted.";  
        }  

        mysqli_stmt_close($stmt);  
    } else {  
        $message = "Error preparing statement: " . mysqli_error($con);  
    }  
} else {  
    $message = "Id not provided.";  
}  

mysqli_close($con);  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">  
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>  
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>  
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>  
    <title>Delete Record</title>  
</head>  
<body>  
    <!-- Modal -->  
    <div class="modal fade" id="notificationModal" tabindex="-1" role="dialog" aria-labelledby="notificationLabel" aria-hidden="true">  
        <div class="modal-dialog" role="document">  
            <div class="modal-content">  
                <div class="modal-header">  
                    <h5 class="modal-title" id="notificationLabel">Information</h5>  
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">  
                        <span aria-hidden="true">&times;</span>  
                    </button>  
                </div>  
                <div class="modal-body">  
                    <p><?php echo $message; ?></p> 
                </div>  
                <div class="modal-footer">  
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>  
                </div>  
            </div>  
        </div>  
    </div>  

    <script>  
        $(document).ready(function() {  
            // modal 
            <?php if(!empty($message)): ?>  
                $('#notificationModal').modal('show');  
            <?php endif; ?>  
        });  
    </script>  
</body>  
</html>