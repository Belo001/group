<?php

$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'career';

// Establish connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $program = $conn->real_escape_string($_POST['program']);
    $message = $conn->real_escape_string($_POST['message']);

    // Insert query
    $sql = "INSERT INTO applying (name, email, phone, program, message) VALUES ('$name', '$email', '$phone', '$program', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "";
    } else {
        echo "<h1>Error:</h1> " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Student Application</title>

    <style>
        
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin-top: 30px;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}
.container{
    background-image: url('graduation.jpg');
    background-repeat: no-repeat;
    background-size: cover;
            display: flex;
            justify-content: center;
            padding: 8px;
        }

form{
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        padding: 0 5rem;
        overflow: hidden;
        grid-column: 1/2;
        grid-row: 1/2;
        transition: 0.2s 0.7s ease-in-out;
    }
    
           .input-field{
        max-width: 380px;
        width: 100%;
        height: 55px;
        background-color: #f0f0f0;
        margin: 10px 0;
        border-radius: 55px;
        display: grid;
        grid-template-columns: 15% 85%;
        padding: 0.4rem;
    }

    .input-field i{
        text-align: center;
        line-height: 55px;
        color: #3a3939;
        font-size: 1.1rem;
    }

    .input-field input{
        background: none;
        outline: none;
        border: none;
        line-height: 1;
        font-weight:600;
        font-size: 1.1rem;
        color: #333;
    }

    .input-field input::placeholder{
        color: #aaa;
        font-weight: 500px;
    }
    .title{
        color: darkcyan;
        font-size: 50px;
        text-decoration: underline overline;
    }
    </style>

</head>
<body>
    <header style="text-align: center;
    margin-bottom: 8px;
    ">
        <h1>
          Career Guidance
        </h1>
        <h2>
            Student Application Form
        </h2>
        <nav style="color: darkcyan;">
            <a href="Dashboard.php">
                Home
            </a>
            <a href="option3.php" style="border-left: 1px white solid;">
                Back
            </a>
        </nav>
        <nav>
            <input type="search" class="srch" placeholder="Type to search ...">
            <button class="btn">Search</button>
        </nav>
    </header>
  
   
    <div class="container">
        <form action="" class="sign-up-form" method="POST">
                    <h2 class="title">Application Form</h2>
                    <div class="input-field">
                        <i class="fa fa-user"></i>
                        <input type="text" placeholder="Full Name" id="name" name="name" required>
                    </div>
                    <div class="input-field">
                        <i class="fa fa-envelope"></i>
                        <input type="email" placeholder="Email" id="email" name="email" required>
                    </div>
                    <div class="input-field">
                        <i class="fa fa-phone"></i>
                        <input type="tel" placeholder="Phone" id="phone" name="phone" required>
                    </div>
                    <div class="input-field">
                        <i class="fa fa-envelope"></i>
                        <input type="program" placeholder="program" id="program" name="program" required>
                    </div>
                    <div class="input-field">
                        <i class="fa fa-envelope"></i>
                        <input type="text" id="message" name="message" placeholder="Requirements">
                    </div>

    
                    <input type="submit" value="Submit" class="btn solid">

                    <p class="social-text">Or Sign up with social platforms</p>
                    <div class="social-media">
                        <a href="#" class="social-icon">
                            <i class="fa fa-facebook-f"></i>
                        </a>

                        <a href="#" class="social-icon">
                            <i class="fa fa-twitter"></i>
                        </a>

                        <a href="#" class="social-icon">
                            <i class="fa fa-instagram"></i>
                        </a>

                        <a href="#" class="social-icon">
                            <i class="fa fa-whatsapp"></i>
                        </a>

                    </div>
                </form>
            </div>
    
</body>
</html>