<?php
include ('connection.php');

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];

    $verify_query = mysqli_query($con, "SELECT Email FROM institute WHERE Email='$email'");

    if (mysqli_num_rows($verify_query) != 0) {
        echo "<div class='message'>
        <p>This email is already used, please try another one!</p>
        </div><br>";
        echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button></a>";
    } else {
        // Hash password for security
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        
        // Insert the data into the database
        $insert_query = mysqli_query($con, "INSERT INTO institute (Name, Email, Phone_Number, Password) VALUES ('$name', '$email', '$phone_number', '$hashed_password')") or die("Database error: " . mysqli_error($con));

        if ($insert_query) {
            // Redirect to login page if registration successful 
            header("Location: InstituteLogin.php");
            exit;
        } else {
            echo "<p>Error Occurred during registration. Please try again.</p>";
        }
    }
} else {

?>

<!DOCTYPE html>
<html>
<head>
    <title>Institude Register</title>

    <style>
body{
    font-family: Helvetica;
}
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin-top: 30px;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-color: #f4f4f4;
}

.header {
    position: fixed;
    top: 0;
    width: 100%;
    padding: 20px;
    background-color: #333;
    color: #fff;
    text-align: center;
}

.header nav a {
    margin: 0 10px;
    color: #fff;
    text-decoration: none;
}

.container {
    background-image: url("graduation.jpg");
    display: flex;
    margin-left: 500px;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    width: 100%;
    margin-top: 100px; 
    margin:auto;

}

.signup-form h3 {
    margin-bottom: 20px;
    font-size: 50px;
    color: darkcyan;
    text-align: center;
    text-decoration: underline overline;
}

.signup-form label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
}

.signup-form input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.signup-form button {
    width: 100%;
    padding: 10px;
    margin-top: 20px;
    background-color: #f4511e;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

.signup-form button:hover {
    background-color: #e0401a;
}


    </style>
    
</head>

<body>
    <header style="text-align: center;
    margin-bottom: 8px;
    ">
        <h1>
          Career Guidance
        </h1><br>
        <h2>
         Institute Register
        </h2><br>
        <nav style="color: darkcyan;">
            <a href="Dashboard.php">
                Home
            </a>
            <a href="#" style="border-left: 1px white solid; border-right: 1px white solid;">
                Settings
            </a>
            <a href="InstituteLogin.php">
                Login
            </a>
        </nav>
        <nav>
            <input type="search" class="srch" placeholder="Type to search ...">
            <button class="btn">Search</button>
        </nav>
    </header>

  

 
    <div class="container">
        <form class="signup-form" action="" method="POST">  
            <h3>Sign Up</h3>
            <label for="name">Name *</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name" required>

            <label for="email">Email *</label>
            <input type="email" id="email" name="email" placeholder="Enter your email address" required>

            <label for="phone_number">Phone Number *</label>
            <input type="tel" id="phone_number" name="phone_number" placeholder="Enter your phone number" required>

            <label for="password">Password *</label>
            <input type="password" id="password" name="password" placeholder="Create a password" required>

            <button type="submit" name="submit">Sign Up</button>  
        </form>
    </div>

</body>
</html>

<?php
}
?>
