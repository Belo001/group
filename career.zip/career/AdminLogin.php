<?php  
session_start();  
include("connection.php");  

if (isset($_POST['submit'])) {  
    $email = mysqli_real_escape_string($con, $_POST['email']);  
    $password = mysqli_real_escape_string($con, $_POST['password']);  

    $result = mysqli_query($con, "SELECT * FROM adminreg WHERE Email = '$email'") or die("Query failed: " . mysqli_error($con));
    $row = mysqli_fetch_assoc($result);  

    if ($row && password_verify($password, $row['Password'])) {  
    
        $_SESSION['valid'] = $row['Email'];  
        $_SESSION['username'] = $row['Username'];  
        $_SESSION['phone'] = $row['Phone'];  
     
        header("Location: option2.php");
        exit;
    } else {  
        echo "<div class='message'><p>Wrong Email or Password</p></div><br>";  
        echo "<a href='AdminLogin.php'><button class='btn'>Go Back</button></a>";  
    }  
} else {
    
?>  

<!DOCTYPE html>
<html>
<head>
    <title>Admin LogIn</title>

    <style>
body{
    font-family: Helvetica;
}
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin-top: 30px;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}
.container{
    background-image: url('graduation.jpg');
    background-repeat: no-repeat;
    background-size: cover;
            display: flex;
            justify-content: center;
            padding: 8px;
        }

        .login-section, .contact-section {
            text-align: center;
        }

        .login-section h2, .contact-section h2 {
            text-align: center; 
            color: darkcyan;
            font-size: 50px;
            margin: 20px 0;
            text-decoration: underline;
        }

     
        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="password"], input[type="email"], textarea {
            margin-bottom: 10px;
            padding: 8px;
            width: 100%;
        }

        button {
            padding: 10px;
            background-color: orange;
            color: white;
            border: none;
            cursor: pointer;
        }
        label{
            color: darkcyan;
            text-align: left;
        }
        #password, #email{
            width: 300px;
            height: 20px;
            border: 1px darkcyan solid;
            color: darkcyan;
        }
        .star{
            color: red;
        }
        .forgot_password{
            margin: 10px 0;
        }
        .bttm_btn{
            display: flex;
            align-items: center;
            justify-content: center;
            margin: auto;
            width: 80px;
            border-radius: 50px;
            border: transparent;
            padding: 10px;
            background-color: orange;
            color: white;
            cursor: pointer;
        }
    </style>
    
</head>

<body>
    <header style="text-align: center;
    margin-bottom: 8px;
    ">
        <h1>
          Career Guidance
        </h1>
        <h2>
        Admin Login
        </h2>
        <nav style="color: darkcyan;">
            <a href="Dashboard.php">
                Home
            </a>
            <a href="#" style="border-left: 1px white solid; border-right: 1px white solid;">
                Settings
            </a>
            <a href="adminregister.php">
                Register
            </a>
        </nav>
        <nav>
            <input type="search" class="srch" placeholder="Type to search ...">
            <button class="btn">Search</button>
        </nav>
    </header>
  
    <div class="container">
     
        <div class="login-section">
            <h2>Login</h2>
            <form action="" method="post">
                <label for="email">Email <span class='star'>*</span></label>
                <input type="text" name="email" id="email" autocomplete="off" placeholder="email" required>

                <label for="password">Password <span class='star'>*</span></label>
                <input type="password" name="password" id="password" placeholder="Enter password">

                <a href="#" class="forgot_password">Forgot Password?</a>
                <button type="submit" class="bttm_btn" name="submit" value="login">Login</button>
            </form>
        </div>

      
       <!-- <div class="contact-section">
            <h2>Contact Us</h2>
            <form>
                <label for="name">Name</label>
                <input type="text" id="name" placeholder="Enter your name">

                <label for="email">Email</label>
                <input type="email" id="email" placeholder="Enter your email">

                <label for="telephone">Telephone</label>
                <input type="text" id="telephone" placeholder="Enter your telephone number">

                <label for="comment">Comment</label>
                <textarea id="comment" placeholder="Enter your comment"></textarea>

                <button type="submit">Submit</button>
            </form>
        </div>-->
    </div>
    <?php } ?>
</body>
</html>
    
