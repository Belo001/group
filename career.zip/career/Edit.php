<?php
// Connect to the database
$con = mysqli_connect("localhost", "root", "", "career");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['email'])) {
    // Use the email to fetch the record
    $email = mysqli_real_escape_string($con, $_GET['email']);
    
    // Fetch record with the specified email
    $query = "SELECT * FROM adminreg WHERE Email = '$email'";
    $result = mysqli_query($con, $query);
    
    // Check if a record was found
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <style>
        
    form h3 {
    margin-bottom: 20px;
    font-size: 24px;
    color: #333;
}

form label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
}

form input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

form button {
    width: 100%;
    padding: 10px;
    margin-top: 20px;
    background-color: #f4511e;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

form button:hover {
    background-color: #e0401a;
}
    </style>
</head>
<body>
    <h2>Edit Record</h2>
    <form action="update.php" method="POST">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($row['Email']); ?>">
        Username: <input type="text" name="username" value="<?php echo htmlspecialchars($row['Username']); ?>"><br>
        Phone Number: <input type="text" name="phone_number" value="<?php echo htmlspecialchars($row['Phone_Number']); ?>"><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>

<?php
    } else {
        echo "No record found.";
    }
} else {
    echo "Email not provided in URL.";
}

// Close connectionn
mysqli_close($con);
?>