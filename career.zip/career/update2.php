<?php
$con = mysqli_connect("localhost", "root", "", "career");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['id'])) {
    $id = mysqli_real_escape_string($con, $_POST['id']);
    $faculty_name = mysqli_real_escape_string($con, $_POST['faculty_name']);
    $program_name = mysqli_real_escape_string($con, $_POST['program_name']);
    $entry_requirements = mysqli_real_escape_string($con, $_POST['entry_requirements']);
    
    $query = "UPDATE faculty SET faculty_name='$faculty_name', program_name='$program_name', entry_requirements='$entry_requirements' WHERE id='$id'";
    
    if (mysqli_query($con, $query)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }
} else {
    echo "ID not provided in form submission.";
}

mysqli_close($con);
?>