<?php  
// Database configuration  
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "career";

// Create connection  
$conn = new mysqli($servername, $username, $password, $dbname);  

// Check connection  
if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
}  

$stmt = $conn->prepare("INSERT INTO applying (course_code, course_name, start_time, end_time, instructor, location, day) VALUES (?, ?, ?, ?, ?, ?, ?)");  
$stmt->bind_param("sssssss", $course_code, $course_name, $start_time, $end_time, $instructor, $location, $day);  

 
$course_code = $_POST['course_code'];  
$course_name = $_POST['course_name'];  
$start_time = $_POST['start_time'];  
$end_time = $_POST['end_time'];  
$instructor = $_POST['instructor'];  
$location = $_POST['location'];  
$day = $_POST['day'];  

// Execute the statement  
if ($stmt->execute()) {  
    echo "New record created successfully";  
} else {  
    echo "Error: " . $stmt->error;  
}  

// Close connections  
$stmt->close();  
$conn->close();  
?>