<?php
$con = mysqli_connect("localhost", "root", "", "career");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['email'])) {
    $email = mysqli_real_escape_string($con, $_GET['email']);
    $query = "DELETE FROM applying WHERE Email='$email'";
    
    if (mysqli_query($con, $query)) {
        echo "Record deleted successfully.";
    } else {
        echo "Error deleting record: " . mysqli_error($con);
    }
} else {
    echo "Email not provided.";
}

mysqli_close($con);


?>