<?php  
        //configuration file  
        include ('connection.php');

        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
      
            $stmt = $conn->prepare("INSERT INTO applying (course_code, course_name, start_time, end_time, instructor, location, day) VALUES (?, ?, ?, ?, ?, ?, ?)");  
            $stmt->bind_param("sssssss", $course_code, $course_name, $start_time, $end_time, $instructor, $location, $day);  

            // Get values from POST request  
            $course_code = $_POST['course_code'];  
            $course_name = $_POST['course_name'];  
            $start_time = $_POST['start_time'];  
            $end_time = $_POST['end_time'];  
            $instructor = $_POST['instructor'];  
            $location = $_POST['location'];  
            $day = $_POST['day'];  

            // Execute the statement  
            if ($stmt->execute()) {  
                echo "New record created successfully";  
            } else {  
                echo "Error: " . $stmt->error;  
            }  

            // Close connections  
            $stmt->close();  
            $conn->close();  
        }  
        ?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
        }

        .course-selection {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            padding: auto;
        }

        input[type="text"], input[type="time"], select {
            width: 48%;
            padding: 10px;
            margin: 5px 0;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #218838;
        }

        .timetable {
            margin-top: 20px;
        }

        .course-details {
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: #f9f9f9;
        }

        .course-details hr {
            margin: 10px 0;
        }

        .remove-btn {
            background-color: #dc3545;
        }

        .remove-btn:hover {
            background-color: #c82333;
        }

        table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
      padding: 10px;
    }
    .course-form {
      margin-bottom: 20px;
    }
    </style>
</head>
<body>
    <div class="container">
        <h1>Course Registration</h1>
        <h2>Select Courses</h2>
        <div class="course-selection">
        
            <input type="text" id="course-input" placeholder="Faculty Name" required>
            <input type="text" id="course-name-input" placeholder="Enter course name" required>
            <input type="time" id="start-time-input" required>
            <input type="time" id="end-time-input" required>
            <input type="text" id="instructor-input" placeholder="Instructor" required>
            <input type="text" id="location-input" placeholder="Location" required>
            <select id="day-input" required>
                <option value="">Select Day</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
            </select>
            <button type="submit" onclick="addCourse()">Add Course</button>
        </div>

        <h2>Your Schedule</h2>
        <table id="scheduleTable">
          <tr>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Instructor</th>
            <th>Location</th>
            <th>Day</th>
            <th>Time</th>
          </tr>
        </table>
      
        <script>
          function addCourse() {
            var table = document.getElementById("scheduleTable");
            var row = table.insertRow(-1);
            var courseCode = document.getElementById("course-input").value;
            var courseName = document.getElementById("course-name-input").value;
            var instructor = document.getElementById("instructor-input").value;
            var location = document.getElementById("location-input").value;
            var day = document.getElementById("day-input").value;
            var startTime = document.getElementById("start-time-input").value;
            var endTime = document.getElementById("end-time-input").value;
            var time = startTime + " - " + endTime;
      
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);
            var cell4 = row.insertCell(3);
            var cell5 = row.insertCell(4);
            var cell6 = row.insertCell(5);
      
            cell1.innerHTML = courseCode;
            cell2.innerHTML = courseName;
            cell3.innerHTML = instructor;
            cell4.innerHTML = location;
            cell5.innerHTML = day;
            cell6.innerHTML = time;
          }
        </script>
   
</body>
</html>

