<?php  
session_start();  
include("connection.php");  

if (isset($_POST['submit'])) {  
    $email = mysqli_real_escape_string($con, $_POST['email']);  
    $password = mysqli_real_escape_string($con, $_POST['password']);  

    $result = mysqli_query($con, "SELECT * FROM institute WHERE Email = '$email'") or die("Query failed: " . mysqli_error($con));
    $row = mysqli_fetch_assoc($result);  

    if ($row && password_verify($password, $row['Password'])) {  
    
        $_SESSION['valid'] = $row['Email'];  
        $_SESSION['name'] = $row['Name'];  
        $_SESSION['phone'] = $row['Phone'];  
     
        header("Location: option.php");  
        exit;
    } else {  
        echo "<div class='message'><p>Wrong Email or Password</p></div><br>";  
        echo "<a href='InstituteLogin.php'><button class='btn'>Go Back</button></a>";  
    }  
} else {
    
?>  


<!DOCTYPE html>  
<html>  
<head>  
    <title>Institute Login</title>  
   
    <style>  
    body{
    font-family: Helvetica;
}
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
header nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin: 15px 0;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}
        body {  
            margin: 0;  
            font-family: Arial, sans-serif;
        }  

        header {  
            text-align: center;  
            margin-bottom: 8px;  
        }  

        nav {  
            color: darkcyan;  
        }  

        nav a {  
            margin: 0 10px;  
            text-decoration: none;  
            color: darkcyan;  
        }  

        nav input.srch {  
            padding: 5px;  
        }  

        nav button.btn {  
            padding: 5px 10px;  
            background-color: darkcyan; 
            color: white;  
            border: none;  
            border-radius: 3px;  
        }  

        .login-container {  
            padding: 15px;  
            background-image: url('graduation.jpg');  
            background-repeat: no-repeat;  
            background-size: cover;  
            border: 1px darkcyan solid;  
            color: darkcyan;  
            width: auto;  
            display
        }  

        .login-title {  
            text-align: center;  
            padding-right: 20px;  
        }  

        .login-title h1 {    
            padding-bottom: 20px;  
            font-size: 40px;
            text-decoration: underline overline;  
        }  

        .form-group {  
            display: block;  
            margin-top: 10px;   
            width: auto;   
        }  
        .label{
            text-align:;
        }  
        .login-button a {  
            padding: 8px 12px;  
            background-color: rgb(245, 95, 0);  
            color: white;  
            border: 0;  
            border-radius: 3px;  
            text-decoration: none;  
        }  
        #password, #email{
            width: 300px;
            height: 40px;
            border: 1px darkcyan solid;
            color: darkcyan;
        }
        .star{
            color: red;
        }
        .forgot_password{
            margin: 10px 0;
        }
    </style>  

</head>  

<body>  
    <header>  
        <h1>Career Guidance</h1>  
        <h2>Institute Login</h2>  
        <nav>  
            <a href="Dashboard.php">Home</a>  
            <a href="Contact_us.html" style="border-left: 1px white solid; border-right: 1px white solid;">Help</a>  
            <a href="InstituteRegister.php">Register</a>  
        </nav>  
        <nav>  
            <input type="search" class="srch" placeholder="Type to search ...">  
            <button class="btn">Search</button>  
        </nav>  
    </header>  
    
    <div class="login-container">  
        <div style="margin: auto;">  
            <div class="login-title">  
                <h1>Institute Login</h1>  

    
                <form action="" method="post"> 
                    <div class="form-group">
                        <label for="email" class="label">Email <span class="star">*</span></label><br>
                        <input type="text" name="email" id="email" autocomplete="off" required>  
                    </div>  

                    <div class="form-group">  
                        <label for="password" class="label">Password <span class="star">*</span></label><br> 
                        <input type="password" name="password" id="password" autocomplete="off" required>  
                    </div>  
                    
                    <div class="login-button">  
                        <input type="submit" class="btn" name="submit" value="Login">
                    </div>  

                    <div class="forgot-password">  
                        <a href="#">Forgot Password?</a>
                    </div>  
                </form>
            </div>  
        </div>  
    </div>  

    <?php } ?>
</body>  
</html> 