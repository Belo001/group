<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Dashboard</title>
    <style>
      body{
        width: auto;
        text-align: center;
        font-family: Helvetica;
      } 
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin-top: 30px;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}
.container{
    background-image: url('graduation-white.jpg');
    background-repeat: no-repeat;
    background-size: cover;
    height: fit-content;
            padding: 8px;

        }
      .faded{
        height: auto;
        width: auto;
        margin: 0 100px;
        padding: 20px;
      }
      .boxes{
        width: 250px;
        color: white;
        background-color: darkcyan;
        display: inline-block;
        margin-left: 15px
      }
      .clickhere{
        color: white;
        padding: 8px;
        border: 1px white solid;
        border-radius: 20px;
        text-decoration: none;
      }
      .clickhere:hover{
        color: darkcyan;
        background-color: white;
        border: 1px black solid;
      }
      .clickhere:active{
        color: white;
        border: 1px white solid;
        background-color: darkcyan;
      }
      .faded h1{
        color: darkcyan;
        font-size: 80px;
        padding-bottom: 60px;
        text-decoration: underline overline;
      }
      .footer {  
        margin-top: 150px;
            background-color:none; 
            color: rgb(0, 0, 0);  
            text-align: center;  
            padding: 20px 0;  
        }  
        .fafa{
          color: orangered;
        }
        h6{
          color: black;
        }
    </style>
    
  </head>
  <body>
    <header style="text-align: center;
    margin-bottom: 8px;
    ">
        <h1>
          Career Guidance
        </h1>
        <h2>
            Student Application Form
        </h2>
        <nav style="color: darkcyan;">
            <a href="Dashboard.php">
                Home
            </a>
            <a href="Contact_us" style="border-left: 1px white solid;">
                Contact_Us
            </a>
        </nav>
        <nav>
            <input type="search" class="srch" placeholder="Type to search ...">
            <button class="btn">Search</button>
        </nav>
    </header>
  <div class="container">

    <div class="faded">
      <h1>
        Dashboard
      </h1>
      <div class="boxes" >
        <h2 style="height: 45px;">
          Profile
        </h2>
        <p style="height: 70px;">

        </p>
        <div  style="height: 45px;">
          <a  class="clickhere"  href="profile.html">Click Here &#8594;</a>
        </div>
      </div>


      <div class="boxes" >
        <h2 style="height: 45px;">
          Apply
        </h2>

        <p style="height: 70px;">
        </p>

        <div style="height: 45px;">
          <a  class="clickhere" href="application.php">Click Here &#8594;</a>
        </div>
      </div>

      <div class="boxes" >
        <h2 style="height: 45px;">
          Admissions
        </h2>

        <p style="height: 70px;">
        </p>

        <div style="height: 45px;">
          <a  class="clickhere" href="admissions.php">Click Here &#8594;</a>
        </div>
      </div>
    <footer class="footer">  
      <p>Terms and Conditions | Privacy Policy | Cookie Policy</p>  
      <h6 id="footerYear">&copy; <script>document.write(new Date().getFullYear());</script> Career Guidance</h6>  
      <div class="fafa">  
          <a href="#"><i class="fa fa-facebook"></i></a>  
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-instagram"></i></a>  
          <a href="#"><i class="fa fa-whatsapp"></i></a>  
          <a href="#"><i class="fa fa-google"></i></a>  
      </div>  

    </div>

  </footer>  
</div>

  </body>
</html>