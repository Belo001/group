<?php   
require_once('connection.php');  
$query = "SELECT * FROM applying";  
$result = mysqli_query($con, $query);  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta http-equiv="X-UA-Compatible" content="IE=edge">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <link rel="stylesheet" href="css/bootstrap.min.css">  
    <title>Application forms table</title>   
    
    <style>  
   
        body {  
            background-color: #343a40;  
            color: #ffffff;  
            font-family: Arial, sans-serif;  
        }  
        .container {  
            width: 80%;  
            margin: auto;  
            text-align: center;  
        }  
        h2 {  
            margin: 20px 0;  
        }  
        table {  
            width: 100%;  
            border-collapse: collapse;  
            margin: 20px 0;  
        }  
        th, td {  
            border: 1px solid #ffffff;  
            padding: 10px;  
            text-align: left;  
        }  
        th {  
            background-color: #495057;  
        }  
        tr:nth-child(even) {  
            background-color: #6c757d;  
        }  
        tr:hover {  
            background-color: #adb5bd;  
        }  

        
        .table-container {  
            position: relative;   
            display: inline-block;
            padding: 5px; 
            overflow: hidden; 
        }  

        .table-container::before {  
            content: "";  
            position: absolute;  
            top: 0;  
            left: 0;  
            right: 0;  
            bottom: 0;  
            z-index: -1;  
            border: 6px solid transparent; 
            border-radius: 10px; 
            background: linear-gradient(45deg, rgba(255, 0, 0, 0.6), rgba(0, 0, 255, 0.6));  
            filter: blur(10px); 
            animation: rotate-border 5s linear infinite; 
        }  

        @keyframes rotate-border {  
            from {  
                transform: rotate(0deg);  
            }  
            to {  
                transform: rotate(360deg);  
            }  
        } 
        
        @keyframes fadeIn {  
    from {  
        opacity: 0;  
        transform: translateY(-10px);  
    }  
    to {  
        opacity: 1;  
        transform: translateY(0);  
    }  
}  

        .table tbody tr {  
    opacity: 0;
    animation: fadeIn 0.6s forwards; 
}  

.table tbody tr:hover {  
    background-color:rgb(124, 44, 87); 
    transition: background-color 0.3s; 
}  


.table tbody tr:nth-child(1) { animation-delay: 0.1s; }  
.table tbody tr:nth-child(2) { animation-delay: 0.2s; }  
.table tbody tr:nth-child(3) { animation-delay: 0.3s; }  
.table tbody tr:nth-child(4) { animation-delay: 0.4s; }  
.table tbody tr:nth-child(5) { animation-delay: 0.5s; }  
.table tbody tr:nth-child(6) { animation-delay: 0.6s; }  
    </style>  
</head>  
<body class="bg-dark">  
    <div class="container">  
        <div class="row mt-5">  
            <div class="col">   
                <div class="card mt-5">   
                    <div class="card-header">  
                        <h2 class="display-6 text-center">Admin Table</h2>  
                    </div>  
                    <div class="card-body">  
                        <table class="table text-center">  
                            <thead class="bg-dark text-white">  
                                <tr>  
                                    <th>Name</th>   
                                    <th>Email</th>  
                                    <th>Phone Number</th>  
                                    <th>Program</th> 
                                    <th>Message</th> 
                                    <th>Accept</th>  
                                    <th>Reject</th>  
                                </tr>  
                            </thead>  
                            <tbody>  
                                <?php  
                                // Check if there are any rows returned  
                                if (mysqli_num_rows($result) > 0) {  
                                    while ($row = mysqli_fetch_assoc($result)) {  
                                ?>  
                                    <tr>  
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>     
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>   
                                        <td><?php echo htmlspecialchars($row['phone']); ?></td>   
                                        <td><?php echo htmlspecialchars($row['program']); ?></td>   
                                        <td><?php echo htmlspecialchars($row['message']); ?></td>  
                                          <td><a href="rejoracc.php?action=accept&email=<?php echo urlencode($row['email']); ?>" class="btn btn-primary">Accept</a></td>  
                                        <td><a href="rejoracc.php?action=reject&email=<?php echo urlencode($row['email']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to reject this record?');"> Reject </a></td>
                                    </tr>  
                                <?php  
                                    }  
                                } else {  
                                    echo "<tr><td colspan='6'>No records found</td></tr>";  
                                }  
                                ?>  
                            </tbody>  
                        </table>  
                    </div>   
                </div>   
            </div>  
        </div>  
    </div>  
</body>  
</html>