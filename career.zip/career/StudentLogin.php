<?php  
session_start();  
include("connection.php");  

if (isset($_POST['submit'])) {  
    $email = mysqli_real_escape_string($con, $_POST['email']);  
    $password = mysqli_real_escape_string($con, $_POST['password']);  
  
    $result = mysqli_query($con, "SELECT * FROM studentreg WHERE Email = '$email'") or die("Query failed: " . mysqli_error($con));  
    $row = mysqli_fetch_assoc($result);  

    if ($row && password_verify($password, $row['password'])) {  
        $_SESSION['valid'] = $row['Email'];  
        $_SESSION['name'] = $row['Name'];  
        $_SESSION['phone'] = $row['Phone_Number'];  
        
  
        header("Location:Option3.php");  
        exit;  
    } else {  
        echo "<div class='message'><p>Wrong Email or Password</p></div><br>";  
        echo "<a href='StudentLogin.php'><button class='btn'>Go Back</button></a>";  
    }  
} else {  
?>  
<!DOCTYPE html>  
<html>  
<head>  
    <title>Student</title>  
  
    <style>
body{
    font-family: Helvetica;
}
header{
    background-color: grey;
    color: white;
    padding: 15px 0;
    text-align: center;
    margin-bottom: 0;
}
nav a{
    color: white;
    padding: 0 15px;
    text-decoration: none;
}
.srch{
    margin-top: 30px;
    height: 40px;
    width: 300px;
    border: 1px orangered solid;
    border-bottom-left-radius: 5px;
    border-top-left-radius: 5px;
    padding-left: 8px;
}
.btn{
    margin-top: 30px;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}
.btn:hover{
  background: darkcyan;
  color: white;
  cursor: pointer;
}
.container {
    background-image: url("graduation.jpg");
    background-repeat: no-repeat;
    background-size: cover;
            display: flex;
            justify-content: center;
        }

        .login-section, .contact-section {
            width: auto; 
            padding: 20px;
        }

        .login-section h2, .contact-section h2 {
            color: darkcyan;
            text-align: center;
            font-size: 50px;
            text-decoration: underline overline;
            margin: 20px 0; 
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="password"], input[type="email"], textarea {
            margin-bottom: 10px;
            padding: 8px;
            width: 300px;
            border: 1px solid darkcyan;
        }

        button {
            padding: 10px;
            background-color: orange;
            color: white;
            border: none;
            cursor: pointer;
        }
        label{
            color: darkcyan;
        } 
.bttm_btn{
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 30px;
    margin: auto;
    height: 40px;
    width: 60px;
    border: 1px orangered solid;
    border-radius: 50px;
    cursor: pointer;
}
.forgot_password{
    text-align: center;
    padding: 10px 0;
}
    </style>

</head>  

<body>  
    <header style="text-align: center; margin-bottom: 8px;">  
        <h1>Career Guidance</h1>  
        <h2>Student Login</h2>  
        <nav style="color: darkcyan;">  
            <a href="Dashboard.php">Home</a>  
            <a href="#" style="border-left: 1px white solid; border-right: 1px white solid;">Settings</a>  
            <a href="Studentregister.php">Register</a>  
        </nav>  
        <nav>  
            <input type="search" class="srch" placeholder="Type to search ...">  
            <button class="btn">Search</button>  
        </nav>  
    </header>  
  
    <div class="container">   
        <div class="login-section">  
            <h2>Student Login</h2>  
            <form method="POST" action="">  
                <label for="email">Email <span style="color: red">*</span></label>  
                <input type="text" id="email" name="email" placeholder="Email" required>  

                <label for="password">Password <span style="color: red">*</span></label>  
                <input type="password" id="password" name="password" placeholder="Enter password" required>  

                <a href="#" class="forgot_password">Forgot Password?</a>  
                <button type="submit" class="bttm_btn" name="submit" value="login">Login</button>  
            </form>  
        </div>  
    </div>  
</body>  
</html>  
<?php  
}  
?>