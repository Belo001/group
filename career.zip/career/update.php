<?php
$con = mysqli_connect("localhost", "root", "", "career");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if email is provided to identify the record
if (isset($_POST['email'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $phone_number = mysqli_real_escape_string($con, $_POST['phone_number']);
    
    // Update the record in the database
    $query = "UPDATE adminreg SET Username='$username', Phone_Number='$phone_number' WHERE Email='$email'";
    
    if (mysqli_query($con, $query)) {
        echo "Record updated successfully.";
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }
} else {
    echo "Email not provided.";
}

mysqli_close($con);
?>