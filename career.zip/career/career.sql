-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2024 at 02:34 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `career`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminreg`
--

CREATE TABLE `adminreg` (
  `Id` int(255) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Phone_Number` int(55) DEFAULT NULL,
  `Password` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminreg`
--

INSERT INTO `adminreg` (`Id`, `Username`, `Email`, `Phone_Number`, `Password`) VALUES
(19, 'Khosi Pheku', 'khosi@gmail.com', 59999999, '$2y$10$37kFPYGuoxwMEF98lPx7peqwcKFqWqQCpJh4RnGKKscNbfbxqHI4e'),
(20, 'Lengau Ntje', 'lengau@gmail.com', 69999999, '$2y$10$8tnBJY1LamwghXe5gFAiX.JCIihzFnfu4CiiYhYivntQFSDMIwofy'),
(21, 'nku', 'nku@gmail.com', 0, '$2y$10$5MVVB/FMPeCDQurfQ22QzOPjaK0/s5QUnGimUySJyNcOLAOrtrGzu'),
(26, 'electricity', 'electro@gmail.com', 0, '$2y$10$FQOTuReRgGGjE83ax98VHuRWhXPyvwuRmDyAY5GKkenm4jZHny0RK'),
(28, 'belly', 'belly@gmail.com', 0, '$2y$10$Fs6ds2cL7hfS0oamvXjOn.yXOGSMdsELxPiS6XZeJ7knwp2.gGHym'),
(30, 'Thabelo', 'thabelomoloisane4@gmail.com', 0, '$2y$10$.2kW4TBBQZzS6DufujYI6uEpW3uV1KGj/Rm1t8TxnOsa27DoBeGLm'),
(31, 'thabelo', 'tha@gmail.com', 0, '$2y$10$WUnhSx8xm3p0LGZseiynBOB87KfP6OJOngZUJflhqCOpbDpCFXKz2');

-- --------------------------------------------------------

--
-- Table structure for table `applying`
--

CREATE TABLE `applying` (
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` int(30) DEFAULT NULL,
  `program` varchar(100) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applying`
--

INSERT INTO `applying` (`name`, `email`, `phone`, `program`, `message`) VALUES
('ozee', 'ozee@gmail.com', 123, 'IT', '3Ds 3Cs'),
('Thabelo Moloisane', 'thabelomoloisane4@gmail.com', 55555555, 'IT', '3Ds 3Cs'),
('tttt', 'tumi@gmail.com', 1111, 'IT', '3Ds 3Cs');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `faculty_name` varchar(255) DEFAULT NULL,
  `program_name` varchar(255) DEFAULT NULL,
  `entry_requirements` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `faculty_name`, `program_name`, `entry_requirements`) VALUES
(1, 'Faculty of Design and Innovation', 'Diploma in Graphic Design', 'Minimum of 3 C grades and 3 D passess'),
(2, 'Faculty of Design and Innovation', 'Diploma in Fashion and Apparel', 'Minimum of 3 C grades and 2 D passes'),
(3, 'Faculty of Media and Broadcasting', 'Degree in Digital Film and TV', 'Minimum of 4 C grades and 2 D passes'),
(4, 'Faculty of Media and Broadcasting', 'Degree in Broadcasting & Journalism', 'Minimum of 4 C grades and 2 D passes'),
(5, 'Faculty of Media and Broadcasting', 'Degree in Professional Comm', 'Minimum of 4 C grades and 2 D passes'),
(6, 'Faculty of Media and Broadcasting', 'Diploma in TV & Film Production', 'Minimum of 3 C grades and 2 D passes'),
(7, 'Faculty of Media and Broadcasting', 'Diploma in Broadcasting', 'Minimum of 3 C grades and 2 D passes'),
(8, 'Faculty of Media and Broadcasting', 'Diploma in Public Relations', 'Minimum of 3 C grades and 2 D passes'),
(9, 'Faculty of Architecture & Built', 'Diploma in Architectural Technology', 'Minimum of 3 C grades and 2 D passes'),
(10, 'Faculty of Business & Globalization', 'Degree in International Business', 'Minimum of 4 C grades and 2 D passes'),
(11, 'Faculty of Business & Globalization', 'Degree in Entrepreneurship', 'Minimum of 4 C grades and 2 D passes'),
(12, 'Faculty of Business & Globalization', 'Degree in Human Resource', 'Minimum of 4 C grades and 2 D passes'),
(13, 'Faculty of Business & Globalization', 'Diploma in Business Management', 'Minimum of 3 C grades and 2 D passes'),
(14, 'Faculty of Business & Globalization', 'Diploma in Marketing', 'Minimum of 3 C grades and 2 D passes'),
(15, 'Faculty of Tourism & Hospitality', 'Degree in Tourism', 'Minimum of 4 C grades and 2 D passes'),
(16, 'Faculty of Tourism & Hospitality', 'Diploma in Tourism', 'Minimum of 3 C grades and 2 D passes'),
(17, 'Faculty of Tourism & Hospitality', 'Diploma in Hotel Management', 'Minimum of 3 C grades and 2 D passes'),
(18, 'Faculty of Tourism & Hospitality', 'Diploma in Events Management', 'Minimum of 3 C grades and 2 D passes'),
(19, 'Faculty of ICT', 'Degree in Software Engineering', 'Minimum of 4 C grades and 2 D passes'),
(20, 'Faculty of ICT', 'Degree in Business IT', 'Minimum of 4 C grades and 2 D passes'),
(21, 'Faculty of ICT', 'Degree in IT', 'Minimum of 4 C grades and 2 D passes');

-- --------------------------------------------------------

--
-- Table structure for table `institute`
--

CREATE TABLE `institute` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Phone_Number` int(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `institute`
--

INSERT INTO `institute` (`ID`, `Name`, `Email`, `Phone_Number`, `Password`) VALUES
(4, 'Limkokwing', 'limko@gmail.com', 69999999, '$2y$10$LcBeAVwWwSC06muFAoCTde/01rJkQeTDUF/5jCaN257AygU.n3Ira'),
(5, 'fokothi', 'fokothi@gmail.com', 51111111, '$2y$10$XdZDoLHjL80/4feTgeDQxO.RXQglpXDY/X4gfKV7Kk1WVWi96Ltpy');

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `rejoracc`
--

CREATE TABLE `rejoracc` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('accepted','rejected') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rejoracc`
--

INSERT INTO `rejoracc` (`id`, `name`, `status`, `created_at`) VALUES
(7, 'ozee', 'rejected', '2024-12-17 01:06:34'),
(8, 'tttt', 'rejected', '2024-12-17 01:18:41'),
(9, 'ozee', 'accepted', '2024-12-17 01:22:05'),
(10, 'ozee', 'accepted', '2024-12-17 01:24:05'),
(11, 'ozee', 'accepted', '2024-12-17 01:25:15'),
(12, 'Thabelo Moloisane', 'rejected', '2024-12-17 01:32:50'),
(13, 'tttt', 'rejected', '2024-12-17 01:33:46');

-- --------------------------------------------------------

--
-- Table structure for table `studentreg`
--

CREATE TABLE `studentreg` (
  `Names` varchar(50) NOT NULL,
  `DOB` date DEFAULT NULL,
  `Phone_number` int(20) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentreg`
--

INSERT INTO `studentreg` (`Names`, `DOB`, `Phone_number`, `Email`, `Username`, `password`) VALUES
('Thabelo Moloisane', '2004-02-27', 63729956, 'thabelomoloisane4@gmail.com', 'Belo', '$2y$10$fzwuH.4RyMHBAVrzs6c1LurInzeeG2IkvWGYrLVB7QC.CU.gmPmMa'),
('Tselisehang Takane', '2000-06-30', 58888888, 'tselisehang@gmaol.com', 'Matshili', '$2y$10$GsySR8GHOSFAsRxTWH/Sj.ZTWbaNxILGZTeJW3ITBRVmw9YYcHj9u'),
('tumi', '2006-09-12', 1111, 'tumi@gmail.com', 'MaddRhonyx', '$2y$10$Pan7s4vbp5PZyhunFeYQzeAHKIfCHLRDV5N7SUSKLxIiK/tmMQpem');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminreg`
--
ALTER TABLE `adminreg`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `institute`
--
ALTER TABLE `institute`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `rejoracc`
--
ALTER TABLE `rejoracc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentreg`
--
ALTER TABLE `studentreg`
  ADD PRIMARY KEY (`Names`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminreg`
--
ALTER TABLE `adminreg`
  MODIFY `Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `institute`
--
ALTER TABLE `institute`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rejoracc`
--
ALTER TABLE `rejoracc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
