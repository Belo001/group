<?php   
require_once('connection.php');  
$query = "SELECT * FROM faculty";  
$result = mysqli_query($con, $query);  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta http-equiv="X-UA-Compatible" content="IE=edge">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <link rel="stylesheet" href="css/bootstrap.min.css">  
    <title>Fetch Data From Database in Php</title>   
    
    <style>  
        body {  
            background-color: #343a40;  
            color: #ffffff;  
            font-family: Arial, sans-serif;  
        }  
        .container {  
            width: 80%;  
            margin: auto;  
            text-align: center;  
        }  
        h2 {  
            margin: 20px 0;  
        }  
        table {  
            width: 100%;  
            border-collapse: collapse;  
            margin: 20px 0;  
        }  
        th, td {  
            border: 1px solid #ffffff;  
            padding: 10px;  
            text-align: left;  
        }  
        th {  
            background-color: #495057;  
        }  
        tr:nth-child(even) {  
            background-color: #6c757d;  
        }  
        tr:hover {  
            background-color: #adb5bd;  
        }  

        
        .table-container {  
            position: relative;   
            display: inline-block;
            padding: 5px; 
            overflow: hidden; 
        }  

        .table-container::before {  
            content: "";  
            position: absolute;  
            top: 0;  
            left: 0;  
            right: 0;  
            bottom: 0;  
            z-index: -1;  
            border: 6px solid transparent; 
            border-radius: 10px; 
            background: linear-gradient(45deg, rgba(255, 0, 0, 0.6), rgba(0, 0, 255, 0.6));  
            filter: blur(10px); 
            animation: rotate-border 5s linear infinite; 
        }  

        @keyframes rotate-border {  
            from {  
                transform: rotate(0deg);  
            }  
            to {  
                transform: rotate(360deg);  
            }  
        } 
        
        @keyframes fadeIn {  
    from {  
        opacity: 0;  
        transform: translateY(-10px);  
    }  
    to {  
        opacity: 1;  
        transform: translateY(0);  
    }  
}  

        .table tbody tr {  
    opacity: 0;
    animation: fadeIn 0.6s forwards; 
}  

.table tbody tr:hover {  
    background-color:rgb(124, 44, 87); 
    transition: background-color 0.3s; 
}  


.table tbody tr:nth-child(1) { animation-delay: 0.1s; }  
.table tbody tr:nth-child(2) { animation-delay: 0.2s; }  
.table tbody tr:nth-child(3) { animation-delay: 0.3s; }  
.table tbody tr:nth-child(4) { animation-delay: 0.4s; }  
.table tbody tr:nth-child(5) { animation-delay: 0.5s; }  
.table tbody tr:nth-child(6) { animation-delay: 0.6s; }  
    </style>  
</head>  
<body class="bg-dark">  
    <div class="container">  
        <div class="row mt-5">  
            <div class="col">   
                <div class="card mt-5">   
                    <div class="card-header">  
                        <h2 class="display-6 text-center">Innovative programmes<br>That Shape Careers Of The Future</h2>  
                    </div>  
                    <div class="card-body">  
                        <div class="table-container">
                            <table class="table text-center">  
                                <thead class="bg-dark text-white">  
                                    <tr>  
                                        <th>ID</th>   
                                        <th>Faculty_Name</th>  
                                        <th>Program_Name</th>  
                                        <th>Entry_Requirements</th>  
                                        <th>Edit</th>  
                                        <th>Delete</th>  
                                    </tr>  
                                </thead>  
                                <tbody>  
                                    <?php  
                                   
                                    if (mysqli_num_rows($result) > 0) {  
                                        while ($row = mysqli_fetch_assoc($result)) {  
                                    ?>  
                                        <tr>  
                                            <td><?php echo htmlspecialchars($row['id']); ?></td>   
                                            <td><?php echo htmlspecialchars($row['faculty_name']); ?></td>   
                                            <td><?php echo htmlspecialchars($row['program_name']); ?></td>   
                                            <td><?php echo htmlspecialchars($row['entry_requirements']); ?></td>   
                                            <td><a href="Edit2.php?id=<?php echo urlencode($row['id']); ?>" class="btn btn-primary"><h2>&#128221;</h2></a></td>  
                                            <td><a href="delete2.php?id=<?php echo urlencode($row['id']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this record?');"><h1><i class="fa fa-trash"></i></h1></a></td>  
                                        </tr>  
                                    <?php  
                                        }  
                                    } else {  
                                        echo "<tr><td colspan='6'>No records found</td></tr>";  
                                    }  
                                    ?>  
                                </tbody>  
                            </table>  
                        </div>
                    </div>   
                </div>   
            </div>  
        </div>  
    </div>  
</body>  
</html>